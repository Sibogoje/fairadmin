<?php
session_start();
$ids=$_POST['id'];
$_SESSION['varname'] = $ids;




//
?>